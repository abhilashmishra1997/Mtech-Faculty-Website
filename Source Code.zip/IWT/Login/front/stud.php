<?php
session_start();
echo($_SESSION['user']);
// attempt database connection
$mysqli = new mysqli("localhost", "root","", "mtech");

if ($mysqli === false) {
die("ERROR: Could not connect. " . mysqli_connect_error());
}
else
{
	$sql = "SELECT * FROM basic WHERE profession='student'"  or die("dead");
//echo($_POST["Email"]);
$mysqli->query($sql);

?>


<!DOCTYPE html>
<html>
<title>M.Tech Programme</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css">
<link rel="stylesheet" href="css/colour.css">
<link rel="stylesheet" href="css/animate.css">
<link href="css/style.css" rel="stylesheet">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script>
function f1()
{
	
}
</script>
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Open Sans", sans-serif}

table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}

</style>
<body class="w3-theme-l5">

 <div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3 l12" style="">
      <!-- Profile -->
      <div class="w3-card-2 w3-round w3-white">
        <div class="w3-container">
         <h4 class="w3-center">List of M.Tech students</h4>
         
         
<?php 
echo("    <table>
  <tr>
    <th>Name</th>
    <th>Email</th>
    <th>Profession</th>
	<th>Visit page</th>
  </tr>");
if ($result = $mysqli->query($sql)) {
    if ($result->num_rows > 0) {
    while($row = $result->fetch_array()) {
    echo("<tr>");
	echo ("<td>".$row[0]."</td>\n");
    echo ("<td>".$row[1]."</td>\n");
	echo("<td>".$row[5]."</td>\n");
	//echo("<td>".$row[3]."</td>\n");
	//$_GET['val']="vales";
        $a=$row[3];
        echo "<td><a href=\"student1.php?link=$a\">Link 1</a></td>";
	echo("</tr>");;
    
    
    
}
$result->close();
} 
else 
{
    echo "No records matching your query were found.";
}
} else
{
    echo "ERROR: Could not execute $sql. " . $mysqli->error;
}
    
}
// close connection
$mysqli->close();
 ?>

 </div>
      </div>
        <hr>
        
      </div>
     </div>
    </div>
    
    </body>

</html>

      