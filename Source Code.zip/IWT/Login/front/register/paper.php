<?php
session_start();
// attempt database connection
$mysqli = new mysqli("localhost", "root","", "mtech");
if ($mysqli === false) {
die("ERROR: Could not connect. " . mysqli_connect_error());
}
else
{
	echo("<h1>Thank you for Registering</h1>");
	//echo ($_POST["user_name"]);
	//echo ($_POST["user_email"]);
	//echo ($_POST["password1"]);
	//echo ($_POST["adhar"]);
}
print_r($_POST);
if(isset($_POST['submit']))
{

}
$name=$_POST["paper_name"];
$intro=$_POST["paper_intro"];
$cla=$_POST["cla"];
$adhar=$_SESSION['user'];
$sql = "INSERT INTO paper(AdharNo, Name, Abstract,Paper_u,classification) VALUES ('$adhar','$name','$intro','','$cla')" or die("dead");
//echo($_POST["Email"]);
$mysqli->query($sql);








$file=$_FILES['file'];;
//echo($file);
print_r($file);
	$file_name=$file['name'];
	$file_type=$file['type'];
	$file_size=$file['size'];
	$file_path=$file['tmp_name'];
	
	if($file_name!=""
	&& ($file_type="image/jpeg"||$file_type="image/png"||file_type=="images/gif")
	&& $file_size <=99999999)
	
	if(move_uploaded_file ($file_path,'img/'.$file_name))
		
	$sql = "update paper set Paper_u='$file_name' where AdharNo='$adhar'" or die("dead");
//echo($_POST["Email"]);
$mysqli->query($sql);


//-------------------------------------------------------------------------------------------------------------------
/*
$sql = "SELECT photo FROM basic where Password='pass'";
if ($result = $mysqli->query($sql)) {
if ($result->num_rows > 0) {
while($row = $result->fetch_array()) {
echo ("<img src='img/".$row[0]. "' height='200px' width='200px'>");
}
$result->close();
} else {
echo "No records matching your query were found.";
}
} else {
echo "ERROR: Could not execute $sql. " . $mysqli->error;
}
	
	
*/












// close connection
$mysqli->close();



?>
