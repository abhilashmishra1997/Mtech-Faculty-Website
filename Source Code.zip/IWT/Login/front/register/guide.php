<?php
session_start();

// attempt database connection
$mysqli = new mysqli("localhost", "root","", "mtech");
if ($mysqli === false)
{
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
echo($_POST['user_name']);
$sql="SELECT * FROM basic WHERE AdharNo=".$_POST['user_name']; 
echo($sql);
if ($result = $mysqli->query($sql)) {
	if ($result->num_rows > 0) {
		$row = $result->fetch_array();
	}
}
print_r($row);
$sql2="insert into mtech_f(AdharNoS,AdharNof) values(".$_SESSION['user'].",".$_POST['user_name'].")";
$mysqli->query($sql2);
?>
