<?php
session_start();
// attempt database connection
$mysqli = new mysqli("localhost", "root","", "mtech");
if ($mysqli === false) {
die("ERROR: Could not connect. " . mysqli_connect_error());
}
else
{
	echo("<h1>Thank you for Registering</h1>");
	//echo ($_POST["user_name"]);
	//echo ($_POST["user_email"]);
	//echo ($_POST["password1"]);
	//echo ($_POST["adhar"]);
}
print_r($_POST);
if(isset($_POST['submit']))
{

}
echo($_SESSION["user"]);
$btech=$_POST["btech"];
$mtech=$_POST["mtech"];
$phd=$_POST["phd"];
$adhar=$_SESSION["user"];
echo($adhar);
$sql = "INSERT INTO qualification(Btech,MTech,PhD,AdharNo) VALUES ('$btech','$mtech','$phd','$adhar')" or die("dead");
//echo($_POST["Email"]);
$mysqli->query($sql);







// close connection
$mysqli->close();



?>
