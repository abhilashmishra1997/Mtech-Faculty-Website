<?php
session_start();

// attempt database connection
$mysqli = new mysqli("localhost", "root","", "mtech");
if ($mysqli === false)
{
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$sql="SELECT * FROM basic A , qualification B WHERE A.AdharNo=B.AdharNo and A.AdharNo=".$_SESSION['user']; 
if ($result = $mysqli->query($sql)) {
	if ($result->num_rows > 0) {
		$row = $result->fetch_array();
	}
}
?>



<!DOCTYPE html>
    <style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>

<title>M.Tech Programme</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css">
<link rel="stylesheet" href="css/colour.css">
<link rel="stylesheet" href="css/animate.css">
<link href="css/style.css" rel="stylesheet">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Open Sans", sans-serif}
</style>
<body class="w3-theme-l5">

<!-- Navbar -->
<div class="w3-top">
 <div class="w3-bar w3-theme-d2 w3-left-align w3-large">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="register/qualification.html" class="w3-bar-item w3-button w3-padding-large w3-theme-d4"><i class="fa fa-home w3-margin-right"></i>Upload Personal Info</a>
  <a href="register/paper.html" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="News">Paper</a>
  <a href="register/thesis.html" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Account Settings">Thesis</a>
   <a href="../logout.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Account Settings">logout</a>
     
 </div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium w3-large">
  <a href="#" class="w3-bar-item w3-button w3-padding-large"></a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large"><?php echo("hello"); ?></a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Logout</a>
</div>

<!-- Page Container -->
    
    <div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3 l12">
      <!-- Profile -->
      <div class="w3-card-2 w3-round w3-white">
        <div class="w3-container">
		
         <h4 class="w3-center"><?php  echo $row[0]; ?></h4>
         <p class="w3-center"><?php echo("<img src='register/img/".$row[4]. "'class='w3-circle' style='height:106px;width:106px' alt='Avatar'>"); ?></p>
         
            <p style="font-weight: bolder;"><i class="fa fa-info w3-margin-right w3-text-theme  " style="font-size:25px;"></i>About</p>
         <p><i class="fa w3-margin-right w3-text-theme"></i> BTech:
             <i class="fa w3-margin-right w3-text-theme"><?php echo($row[6]);?></i></p>
        <p><i class="fa w3-margin-right w3-text-theme"></i> MTech:
             <i class="fa w3-margin-right w3-text-theme"><?php echo($row[7]);?></i></p>
         <p><i class="fa w3-margin-right w3-text-theme"></i> PhD:
             <i class="fa w3-margin-right w3-text-theme"><?php echo($row[8]);?></i></p>
          
		  </div>
      </div>
      <br>

      <!-- Show all students -->
      <div class="w3-card-2">
        <div class="w3-white w3-round">
          <button onclick="myFunction('Demo1')" class="w3-button w3-block w3-theme-l1 w3-left-align">
              <i class="fa fa-circle-o-notch fa-fw w3-margin-right"></i><a href="stud.php"> View all Students</a></button>
        </div>
      </div>
      <br>
    

      </div>

    <!-- Middle Column -->
    <div class="w3-col m7">

      <div class="w3-container w3-card-2 w3-white w3-round w3-margin"><br>
        <!img src="/w3images/avatar2.png" alt="Avatar" class="w3-left w3-circle w3-margin-right" style="width:60px">
        
        <h4 style="text-align:center;">Research Papers</h4><br>
        <hr class="w3-clear">
<?php
          $sql2="select * from paper where AdharNo=".$_SESSION['user'];
          
 echo("         
<table>
  <tr>
    <th>Title</th>
    <th>Introduction</th>
    <th>Classification</th>
    <th>Download</th>
  </tr>
  ");
     

if ($result2= $mysqli->query($sql2)) {
	if ($result2->num_rows > 0) {
        //echo($result2->num_rows);
		
        for($i=0;$i<$result2->num_rows;$i++)
        {
            $row2 = $result2->fetch_array();
        //print_r($row2);
     echo("<tr>");
    echo("<td>".$row2[1]."</td>");
    echo("<td>".$row2[2]."</td>");
    echo("<td>".$row2[3]."</td>");
    echo("<td><a href=register/img/".$row2[3].">Download</a></td>");
        
  echo("</tr>");
  }
    }
}
echo("</table>");
          
          
          
?>          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
            <div class="w3-container w3-card-2 w3-white w3-round w3-margin"><br>
        <h4 style="text-align:center;">MTech Thesis</h4><br>
        <hr class="w3-clear">
        <p>
          
          
          
          <?php
          $sql3="select * from thesis_u where AdharNo=".$_SESSION['user'];
          
 echo("         
<table>
  <tr>
    <th>Title</th>
    <th>Introduction</th>
    <th>Classification</th>
    <th>Download</th>
  </tr>
  ");
     

if ($result3= $mysqli->query($sql3)) {
	if ($result3->num_rows > 0) {
        //echo($result2->num_rows);
		
        for($i=0;$i<$result3->num_rows;$i++)
        {
            $row3 = $result3->fetch_array();
        //print_r($row2);
     echo("<tr>");
    echo("<td>".$row3[1]."</td>");
    echo("<td>".$row3[2]."</td>");
    echo("<td>".$row3[3]."</td>");
    echo("<td><a href=register/img/".$row3[3].">Download</a></td>");
        
  echo("</tr>");
  }
    }
}
echo("</table>");
          

          
          
          
?>          
          
          
          
          
          
          
          
          
          
          
          
          
        
      </div>
</div>
       

    <!-- End Middle Column -->
    </div>

    <!-- Right Column -->
    <div class="w3-col m4">
      <div class="w3-card-2 w3-round w3-white w3-center">
        <div class="w3-container">
          <p>Upcoming Events:</p>
          <img src="/w3images/forest.jpg" alt="Forest" style="width:100%;">
          <p><strong>Holiday</strong></p>
          <p>Friday 15:00</p>
          <p><button class="w3-button w3-block w3-theme-l4">Info</button></p>
        </div>
      </div>
      <br>

      <div class="w3-card-2 w3-round w3-white w3-center w3-padding-16">
        <div class="w3-container">
          <p>ADS</p>
          <div class="w3-row w3-opacity">
          </div>
        </div>
      </div>
      <br>

      <div class="w3-card-2 w3-round w3-white w3-padding-16 w3-center">
        <p>ADS</p>
      </div>
      <br>

      <div class="w3-card-2 w3-round w3-white w3-padding-32 w3-center">
        <p><i class="fa fa-bug w3-xxlarge"></i></p>
      </div>

    <!-- End Right Column -->
    </div>

  <!-- End Grid -->
  </div>

<!-- End Page Container -->
</div>
<br>


<!-- Footer -->

<div class="w3-container w3-theme-d5 foot">Terms . Privacy . License<br>
    <div style="font-weight:lighter;"> copyright 2017 | M.Tech Programme VSSUT, Burla</div>
</div>

<script>
// Accordion
function myFunction(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className += " w3-theme-d1";
    } else {
        x.className = x.className.replace("w3-show", "");
        x.previousElementSibling.className =
        x.previousElementSibling.className.replace(" w3-theme-d1", "");
    }
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
    var x = document.getElementById("navDemo");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else {
        x.className = x.className.replace(" w3-show", "");
    }
}
</script>

</body>
</html>
