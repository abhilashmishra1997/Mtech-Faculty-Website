<!DOCTYPE html>
<html>
<title>My Web</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="w3.css">

    
<?php
// attempt database connection
$mysqli = new mysqli("localhost", "root","", "mtech");
if ($mysqli === false)
{
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
else
{
    
	echo("<h1 style='text-align:center'>Welcome</h1>");
    session_start();
    $user=$_POST['Email'];
    $pass=$_POST['password'];
    //print_r($_POST);
    //echo($_SESSION['user']);
    $sql = "SELECT * FROM basic where Email='$user' and Password='$pass'";
    if ($result = $mysqli->query($sql)) {
    if ($result->num_rows > 0) {
    while($row = $result->fetch_array()) {
    echo ("<h1 style='text-align:center'>".$row[0]."</h1>\n");
    //echo("<h1>".$row[3]);
    $_SESSION['user']=$row[3];
    if($row[5]=="professor")
	{echo("<a href='front/prof.php'><button class='w3-button w3-red w3-border'>continue</button></a>");  
		header("Location:front/prof.php");}
    else
	{echo("<a href='front/student.php?'><button class='w3-button w3-red w3-border'>continue</button></a>");  
		header("Location:front/student.php");}
$result->close();
	}} 
else 
{
    echo "No records matching your query were found.";
}
} else
{
    echo "ERROR: Could not execute $sql. " . $mysqli->error;
}
    
}
// close connection
$mysqli->close();
 
?>
