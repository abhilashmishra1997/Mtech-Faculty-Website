<?php
$mysqli = new mysqli("localhost", "root","", "mtech");
if ($mysqli === false) {
die("ERROR: Could not connect. " . mysqli_connect_error());
}
//print_r($_FILES);
if($_POST['submit'])
{
	$file=$_FILES['file'];
	$file_name=$file['name'];
	$file_type=$file['type'];
	$file_size=$file['size'];
	$file_path=$file['tmp_name'];
	echo($file_path);
	
	if($file_name!=""
	&& ($file_type="image/jpeg"||$file_type="image/png"||file_type=="images/gif")
	&& $file_size <=99999999)
	
	if(move_uploaded_file ($file_path,'img/'.$file_name))
		
	$sql = "update basic set photo='$file_name' where Password='pass'" or die("dead");
//echo($_POST["Email"]);
$mysqli->query($sql);


//-------------------------------------------------------------------------------------------------------------------

$sql = "SELECT photo FROM basic where Password='pass'";
if ($result = $mysqli->query($sql)) {
if ($result->num_rows > 0) {
while($row = $result->fetch_array()) {
echo ("<img src='img/".$row[0]. "' height='200px' width='200px'>");
echo("<a href=img/".$row[0].">Download</a>");
}
$result->close();
} else {
echo "No records matching your query were found.";
}
} else {
echo "ERROR: Could not execute $sql. " . $mysqli->error;
}
	
	
}
?>